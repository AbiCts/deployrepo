package com.api_gateway_service.swaggerconfig;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    public static final String CSRF_HEADER_NAME = "X-CSRF-TOKEN";
    
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info().title("Customer API").version("1.0"))
                // Add a security requirement to include the CSRF header for protected endpoints
                .addSecurityItem(new SecurityRequirement().addList(CSRF_HEADER_NAME))
                .components(new io.swagger.v3.oas.models.Components()
                   .addSecuritySchemes(CSRF_HEADER_NAME, 
                        new SecurityScheme()
                            .name(CSRF_HEADER_NAME)
                            .type(SecurityScheme.Type.APIKEY)
                            .in(SecurityScheme.In.HEADER)
                            .description("CSRF token (retrieved from a GET request or session)")));
    }
}

