package com.api_gateway_service.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api")
@RestController
public class Controller {

	 @GetMapping("/csrf-token")
	    public Map<String, String> csrf(CsrfToken token) {
	        // Create a map containing the CSRF token details
	        Map<String, String> tokenMap = new HashMap<>();
	        tokenMap.put("headerName", token.getHeaderName());
	        tokenMap.put("parameterName", token.getParameterName());
	        tokenMap.put("token", token.getToken());
	        return tokenMap;
	    }
}
