package com.api_gateway_service.securityconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Enable CSRF protection with a session-based token repository.
            .csrf(csrf -> csrf.csrfTokenRepository(csrfTokenRepository()))
            
            // Session management: choose your session fixation strategy.
            .sessionManagement(session -> session.sessionFixation().migrateSession())

            
            // Define endpoint access rules.
            .authorizeHttpRequests(auth -> auth
                // Swagger endpoints should be accessible to all.
                .requestMatchers("/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**", "/swagger-resources/**", "/webjars/**").permitAll()
                // Permit your other public endpoints.
                .requestMatchers("/user/**", "/api/**", "/logging/**", "/email/**", "/assessments/**", "/submissions/**", "/course/**", "/enrollment/**").permitAll()
                // All other endpoints require authentication.
                .anyRequest().authenticated()
            );

        return http.build();
    }
    
    @Bean
    public CsrfTokenRepository csrfTokenRepository() {
        HttpSessionCsrfTokenRepository repo = new HttpSessionCsrfTokenRepository();
        repo.setHeaderName("X-CSRF-TOKEN");
        return repo;
    }
}
